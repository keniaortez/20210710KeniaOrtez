﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Data.SqlClient;

// NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código, en svc y en el archivo de configuración.
public class Service : IService
{
	public DataSet GetRegistro(int idRegistro)
	{
        DataSet ds = new DataSet();
        string Cnn = System.Configuration.ConfigurationManager.ConnectionStrings["CnStr"].ConnectionString;
        try
        {            
            SqlConnection Cn = new SqlConnection(Cnn);
            string sql = "sp_getRegistros";
            SqlDataAdapter da = new SqlDataAdapter(sql, Cn);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@idRegistro", idRegistro);
            da.Fill(ds);
        }
        catch (Exception ex)
        {
            ds.Clear();
        }
        return ds;
	}



	public string InsertRegistro(string Nombre, string Apellido, string Direccion, int Telefono, string Marca, string Modelo, int Anio, Boolean Reserva)
	{
		string resp = "";
		try
		{
			int idReg = 0;
			string Cnn = System.Configuration.ConfigurationManager.ConnectionStrings["CnStr"].ConnectionString;
			SqlConnection Cn = new SqlConnection(Cnn);
			string sql = "";

			if (Reserva)
			{
				sql = "sp_InsertReserva";
			}
			else 
			{
				sql = "sp_InsertCompra";
			}
			
			SqlCommand cmd = new SqlCommand(sql, Cn);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.AddWithValue("@Nombre", Nombre);
			cmd.Parameters.AddWithValue("@Apellido", Apellido);
			cmd.Parameters.AddWithValue("@Direccion", Direccion);
			cmd.Parameters.AddWithValue("@Telefono", Telefono);
			cmd.Parameters.AddWithValue("@Marca", Marca);
			cmd.Parameters.AddWithValue("@Modelo", Modelo);
			cmd.Parameters.AddWithValue("@Anio", Anio);
			Cn.Open();
			idReg = int.Parse(cmd.ExecuteScalar().ToString().Trim());
			Cn.Close();
			resp = "OK";
		}
		catch (Exception ex)
		{
			resp = ex.ToString();
		}
		return resp;
	}



}
