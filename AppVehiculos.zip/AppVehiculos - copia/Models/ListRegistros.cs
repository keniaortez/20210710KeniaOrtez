﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AppVehiculos.Models;
using System.Data;

namespace AppVehiculos.Models
{
    public class ListRegistros
    {
        public List<Vehiculo> vehi { get; set; }

        public ListRegistros()
        { 
        }

        public Boolean getRegistros(int ID) 
        {
            Boolean resp = false;
            try
            {
                using (wcfVehiculo.Service wcf = new wcfVehiculo.Service())
                {
                    DataSet ds = new DataSet();
                    vehi = new List<Vehiculo>();
                    ds = wcf.GetRegistro(0, true);
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                int IdREgistro = int.Parse(dr["IdREgistro"].ToString().Trim());
                                string Nombre = dr["Nombre"].ToString().Trim();
                                string Apellido = dr["Apellido"].ToString().Trim();
                                string Direccion = dr["Direccion"].ToString().Trim();
                                int Telefono = int.Parse(dr["Telefono"].ToString().Trim());
                                string Marca = dr["Marca"].ToString().Trim();
                                string Modelo = dr["Modelo"].ToString().Trim();
                                int Anio = int.Parse(dr["Anio"].ToString().Trim());
                                Boolean Reserva = Boolean.Parse(dr["Reserva"].ToString().Trim());
                                Boolean Compra = Boolean.Parse(dr["Compra"].ToString().Trim());
                                string FechaReserva = dr["FechaReserva"].ToString().Trim();
                                string FechaCompra = dr["FechaCompra"].ToString().Trim();
                                Vehiculo obj = new Vehiculo(IdREgistro, Nombre, Apellido, Direccion, Telefono,Marca,Modelo, Anio, Reserva, Compra,FechaReserva,FechaCompra);
                                vehi.Add(obj);
                                resp = true;
                            }
                        }
                        else
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                resp = false;
            }
            return resp;
        }
    }
}