﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.ComponentModel.DataAnnotations;


namespace AppVehiculos.Models
{
    public class Vehiculo
    {
       
        public int IdREgistro { get; set; }
        [Display(Name = "Nombre")]
        [Required(ErrorMessage = "El campo {0} es obligatorio")]
        public string Nombre { get; set; }
        [Display(Name = "Apellido")]
        [Required(ErrorMessage = "El campo {0} es obligatorio")]
        public string Apellido { get; set; }
        [Display(Name = "Dirección")]
        [Required(ErrorMessage = "El campo {0} es obligatorio")]
        public string Direccion { get; set; }
        [Display(Name = "Teléfono")]
        [Required(ErrorMessage = "El campo {0} es obligatorio")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "* Solo se permiten números *")]
        public int Telefono { get; set; }
        [Display(Name = "Marca")]
        [Required(ErrorMessage = "El campo {0} es obligatorio")]
        public string Marca { get; set; }
        [Display(Name = "Modelo")]
        [Required(ErrorMessage = "El campo {0} es obligatorio")]
        public string Modelo { get; set; }
        [Display(Name = "Año")]
        [Required(ErrorMessage = "El campo {0} es obligatorio")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "* Solo se permiten números *")]
        public int Anio { get; set; }
        public Boolean Reserva { get; set; }
        public Boolean Compra { get; set; }
        public string FechaReserva { get; set; }
        public string FechaCompra { get; set; }



        public Vehiculo() 
        {

         
        }
        public Vehiculo(int id, string nombre, string apellido, string direccion, int telefono, string marcar, string modelo, int anio, Boolean reserva, Boolean compra, string fechaReserv, string fechaComp) 
        {
            IdREgistro = id;
            Nombre = nombre;
            Apellido = apellido;
            Direccion = direccion;
            Telefono = telefono;
            Marca = marcar;
            Modelo = modelo;
            Anio = anio;
            Reserva = reserva;
            Compra = compra;
            FechaReserva = fechaReserv;
            FechaCompra = fechaComp;
        }

        public Boolean InsertarRegistro() 
        {
            Boolean resp = false;

            try
            {
                using (wcfVehiculo.Service wcf = new wcfVehiculo.Service()) 
                {
                    string r = wcf.InsertRegistro(Nombre, Apellido, Direccion, Telefono, true, Marca, Modelo, Anio, true, Reserva, true);
                    if (r.Trim().ToString() == "OK")
                    {
                        resp = true;
                    }
                }
            }
            catch (Exception ex) 
            {
            
            }

            return resp;
        }
    }
}