﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AppVehiculos.Models;

namespace AppVehiculos.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpGet]
        public ActionResult ListaRegistros() 
        {
            ListRegistros veh = new ListRegistros();
            veh.getRegistros(0);
            return View(veh);
        }



        //Reserva
        [HttpGet]
        public ActionResult Reserva()
        {

            return View();
        }

        [HttpPost]
        public ActionResult Reserva(Vehiculo veh)
        {
            veh.Reserva = true;            
            if (ModelState.IsValid)
            {
                Boolean insert = veh.InsertarRegistro();
                if (insert)
                {
                    return RedirectToAction("ListaRegistros");
                }
                else
                {
                    return View(veh);
                }
            }
            else
            {
                return View(veh);
            }
        }

        //Compra
        [HttpGet]
        public ActionResult Compra()
        {

            return View();
        }

        [HttpPost]
        public ActionResult Compra(Vehiculo veh)
        {
            veh.Reserva = false;
            if (ModelState.IsValid)
            {
                Boolean insert = veh.InsertarRegistro();
                if (insert)
                {
                    return RedirectToAction("ListaRegistros");
                }
                else
                {
                    return View(veh);
                }
            }
            else
            {
                return View(veh);
            }
        }
    }
}